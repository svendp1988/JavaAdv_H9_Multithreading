package be.pxl.multithreading.oef1;

public class TalkerApp {

	public static void main(String[] args) {
		for (int i = 0 ; i < 4; i++) {
			new Thread(new Talker(i)).start();
		}
	}

}
